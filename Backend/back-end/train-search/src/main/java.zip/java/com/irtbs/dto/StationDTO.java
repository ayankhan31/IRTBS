package com.irtbs.dto;

public interface StationDTO {
	public int getFrom_station_id();
	public int getTo_station_id();
}
