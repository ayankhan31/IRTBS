package com.irtbs.dto;

public interface CoachDTO {
	public int getCoach_id();
}
