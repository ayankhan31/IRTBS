package com.irtbs.trainsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
